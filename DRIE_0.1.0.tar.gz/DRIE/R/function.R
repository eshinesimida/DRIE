#the function: the score between drug-induced gene and disease-related gene
#g4: diseae-specific network
#from: drug-induced gene
#to: diseae-related gene
get_r2 <- function(g4,from,to){

  #pathway <- prcocess_g(mapkG3)
  if(from == to){
    FC <- fc[strsplit(from,':')[[1]][2]]
    #if(FC >0){
    # y = 1
    # }else{
    # y = -1
    #}
    y <- FC

  }else{

    A <- get.shortest.paths(g4, from ,to)

    if(length(A$vpath[[1]]) == 1){
      y = 0
    }else{
      edge1 <- mapkG3@edgeData@data#?ߵ?????
      L <- length(A$vpath[[1]])-1#???̾???
      E_type <- c()
      nodes <- A$vpath[[1]]
      for(i in 1:L){

        e <- edge1[paste(names(nodes[[i]]),'|',names(nodes[[i+1]]),sep = '')]
        E_type <- c(E_type,e[[1]]$weight)
      }

      FC <- fc[strsplit(from,':')[[1]][2]]
      S <- cumprod(E_type)
      s <- tail(S, 1)
      I <- FC*s/(L+1)
      #if(I > 0){
      #  y <- 1
      #}else{
      #  y <- -1
      #}
      y <- I

    }


  }
  y
}

process <- function(x){
  y <- gsub('hsa:','',x)
  y
}


# function :get lung cancer-related pathways from KEGG database
get_pathway <- function(){
  library(DrugDiseaseNet)
  library(graph)
  library(graphite)
  library(Rgraphviz)
  library(SPIA)
  library(XML)


  kgml.path=system.file("extdata/keggxml/hsa",package="SPIA")
  mdir = kgml.path
  paths <- dir(mdir,pattern=".xml")
  genes_CRC <- c()
  for(i in 1:8){
    gg <-try(parseKGML(paste(mdir,paths[i],sep="/")),TRUE)

    mapkG3<-KEGGpathway2Graph(gg,expandGenes=T)
    genes_CRC <- c(genes_CRC, nodes(mapkG3))


  }
  genes_CRC1 <- unique(genes_CRC)


  library(DrugDiseaseNet)
  library(graph)
  gg<-keggGlobalGraph()

  kegg_genes <- process(nodes(gg))

  genes1 <- c('hsa:4790', 'hsa:5599', 'hsa:1839', 'hsa:253959', 'hsa:57148', 'hsa:57186', 'hsa:53373',
              'hsa:4486', 'hsa:844', 'hsa:845', 'hsa:10345', 'hsa:444', 'hsa:3270', 'hsa:255231', 'hsa:55283',
              'hsa:57192', 'hsa:2668', 'hsa:4485', 'hsa:10393', 'hsa:119504', 'hsa:246184', 'hsa:25847', 'hsa:25906',
              'hsa:29882', 'hsa:29945', 'hsa:51433', 'hsa:51434', 'hsa:51529', 'hsa:64682', 'hsa:8697', 'hsa:8881',
              'hsa:996', 'hsa:4088', 'hsa:10572', 'hsa:84883')

  m1 <- setdiff(genes_CRC1 , genes1)

  gg1 <- subGraph(m1,gg)


  mapkG3<-gg1
  mapkG3
}
